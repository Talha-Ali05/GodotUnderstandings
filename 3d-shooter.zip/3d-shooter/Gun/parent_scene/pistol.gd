extends GunModel
